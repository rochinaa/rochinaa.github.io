struct TPictureClickFuncParam
{ DWORD servSize;
  int Command;
};
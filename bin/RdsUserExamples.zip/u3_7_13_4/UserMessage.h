struct TUserMessageFuncParam
{ DWORD servSize;
  int Type;
    #define UMFP_TYPE_INF  0
    #define UMFP_TYPE_WARN 1
    #define UMFP_TYPE_ERR  2
  char *Message;
};